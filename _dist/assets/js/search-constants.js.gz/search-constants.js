var JEKYLL_PAGES_API_SEARCH_INDEX_URL = '/Help/search-index.json';
